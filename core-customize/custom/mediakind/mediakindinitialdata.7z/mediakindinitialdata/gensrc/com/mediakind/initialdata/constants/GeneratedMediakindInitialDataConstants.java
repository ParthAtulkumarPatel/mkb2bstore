/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 18 Aug, 2019 1:48:53 PM                     ---
 * ----------------------------------------------------------------
 */
package com.mediakind.initialdata.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedMediakindInitialDataConstants
{
	public static final String EXTENSIONNAME = "mediakindinitialdata";
	
	protected GeneratedMediakindInitialDataConstants()
	{
		// private constructor
	}
	
	
}
